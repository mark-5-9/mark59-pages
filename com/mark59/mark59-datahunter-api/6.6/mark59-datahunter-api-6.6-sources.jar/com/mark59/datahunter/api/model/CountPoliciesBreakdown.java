/*
 *  Copyright 2019 Mark59.com
 *  
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  you may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at
 *  
 *      http://www.apache.org/licenses/LICENSE-2.0
 *      
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.mark59.datahunter.api.model;


/**
 * @author Philip Webb
 * Written: Australian Winter 2019
 */
public class CountPoliciesBreakdown extends PolicySelectionCriteria   {

	Long rowCount;
	String isReusableIndexed;
	Long holeCount;	
	
	public CountPoliciesBreakdown() {
	}

	public Long getRowCount() {
		return rowCount;
	}

	public void setRowCount(Long rowCount) {
		this.rowCount = rowCount;
	}
	
	public String getIsReusableIndexed() {
		return isReusableIndexed;
	}

	public void setIsReusableIndexed(String isReusableIndexed) {
		this.isReusableIndexed = isReusableIndexed;
	}

	public Long getHoleCount() {
		return holeCount;
	}

	public void setHoleCount(Long holeCount) {
		this.holeCount = holeCount;
	}

	@Override
    public String toString() {
        return  super.toString() + 
        		", rowCount="+ rowCount +         		
        		", isReusableIndexed="+ isReusableIndexed +         		
        		", holeCount="+ holeCount +         		
        		"]";
	}
		
}
